﻿using Terraria.ID;
using Terraria.ModLoader;

namespace MoreBiomesPlus.Blocks
{
    public class FertileGrass : ModItem
    {
		public override void SetStaticDefaults()
		{
			// DisplayName.SetDefault("Fertile Dirt"); // By default, capitalization in classnames will add spaces to the display name. You can customize the display name here by uncommenting this line.
			Tooltip.SetDefault("Dound on the grassy slopes of Terrarian Mountains.");
		}
		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.MudBlock, 4);
			recipe.AddTile(TileID.WorkBenches);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}
