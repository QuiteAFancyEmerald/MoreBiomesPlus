using Terraria.ModLoader;

namespace MoreBiomesPlus
{
	public class MoreBiomesPlus : Mod
	{
	}
}